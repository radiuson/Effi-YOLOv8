# Tomato Leaf DIseases Detect > 2024-03-04 3:55pm
https://universe.roboflow.com/sylhet-agricultural-university/tomato-leaf-diseases-detect

Provided by a Roboflow user
License: Public Domain

